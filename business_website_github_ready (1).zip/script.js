function order(){
alert("Thank you for your interest! Contact us to place your order.");
}
